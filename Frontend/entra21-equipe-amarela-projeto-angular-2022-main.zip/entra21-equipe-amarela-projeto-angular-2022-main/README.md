# entra21-equipe-amarela-projeto-angular-2022
Repositório dedicado ao projeto de angular da equipe amarela
